self.__precacheManifest = [
  {
    "revision": "2a62280a53d663b0f2ad",
    "url": "/static/css/main.cd672388.chunk.css"
  },
  {
    "revision": "2a62280a53d663b0f2ad",
    "url": "/static/js/main.616dafc2.chunk.js"
  },
  {
    "revision": "d28ee909911c7187af0d",
    "url": "/static/js/runtime~main.c0e55c90.js"
  },
  {
    "revision": "70970351751ef1e6661e",
    "url": "/static/css/2.51053c8d.chunk.css"
  },
  {
    "revision": "70970351751ef1e6661e",
    "url": "/static/js/2.a7a7185d.chunk.js"
  },
  {
    "revision": "71dca0aadb016c70d99ff6cd579f431e",
    "url": "/static/media/2.71dca0aa.jpg"
  },
  {
    "revision": "8954a0ff8c0bcfbfdad1f1f41e5b09af",
    "url": "/static/media/3.8954a0ff.jpg"
  },
  {
    "revision": "ccdc1ddb972e9c5611fc06bca359da2c",
    "url": "/static/media/1.ccdc1ddb.jpg"
  },
  {
    "revision": "f637caf0d5e20175465e535a70950c59",
    "url": "/static/media/zwz-log-logo.f637caf0.png"
  },
  {
    "revision": "9913905d01a70cb9af7a02ab84839aa4",
    "url": "/static/media/currency.9913905d.svg"
  },
  {
    "revision": "31dec74e825fcfc7aac18726c24dc5d7",
    "url": "/static/media/trans_nod_logo.31dec74e.png"
  },
  {
    "revision": "e4cd22fc23b48694f302a5cc17f9eae4",
    "url": "/static/media/nod-logo.e4cd22fc.jpg"
  },
  {
    "revision": "512781f4b952c93293f63ef8d3ceb4d7",
    "url": "/static/media/logos.512781f4.jpg"
  },
  {
    "revision": "2feb69ccb596730c72920c6ba3e37ef8",
    "url": "/static/media/revicons.2feb69cc.eot"
  },
  {
    "revision": "17629a5dfe0d3c3946cf401e1895f091",
    "url": "/static/media/revicons.17629a5d.ttf"
  },
  {
    "revision": "04eb8fc57f27498e5ae37523e3bfb2c7",
    "url": "/static/media/revicons.04eb8fc5.woff"
  },
  {
    "revision": "e4ef7f1d0730c82126c02c56119fd7a4",
    "url": "/static/media/4.e4ef7f1d.jpg"
  },
  {
    "revision": "0f3c5b8f621d00641f84725bcd104bdb",
    "url": "/static/media/5.0f3c5b8f.jpg"
  },
  {
    "revision": "d0cf492d066b2c0ef28ec35af7f0c744",
    "url": "/static/media/bearings1.d0cf492d.jpg"
  },
  {
    "revision": "a13ba344e76c1643559848cd9e64ea1e",
    "url": "/static/media/share.a13ba344.png"
  },
  {
    "revision": "2698839b07e0c849df482fd4f6e9b1d4",
    "url": "/static/media/logo.2698839b.svg"
  },
  {
    "revision": "d91e227054e0f2bed43310de91b38136",
    "url": "/static/media/client_detail_img1.d91e2270.jpg"
  },
  {
    "revision": "265cd7d5239effb368ca3b1f70b22891",
    "url": "/static/media/client_detail_img2.265cd7d5.jpg"
  },
  {
    "revision": "1d7479f7dce81ea552ce456e2bdf20ee",
    "url": "/static/media/client_detail_img3.1d7479f7.jpg"
  },
  {
    "revision": "767e86dfa342469ae26244b1c6c097b5",
    "url": "/static/media/client_detail_img4.767e86df.jpg"
  },
  {
    "revision": "1347a39895860be70d42db4e8b67d112",
    "url": "/static/media/rsz_1banner_slider1.1347a398.jpg"
  },
  {
    "revision": "3c802248bf9dcce2d6efd7fde7c1dba5",
    "url": "/static/media/rsz_1banner_slider2.3c802248.jpg"
  },
  {
    "revision": "6862db4409d4af4e28305fd688c8c682",
    "url": "/static/media/rsz_banner_slider3.6862db44.jpg"
  },
  {
    "revision": "eb5877e0702c18ea1a8753fa5e128b8a",
    "url": "/static/media/rsz_banner_slider4.eb5877e0.jpg"
  },
  {
    "revision": "3876cbd222d19570bbef6e110e19214a",
    "url": "/static/media/rsz_banner_slider5.3876cbd2.jpg"
  },
  {
    "revision": "522ef4163aabcf2f1c396b9fd62c24af",
    "url": "/static/media/zwzproduct11.522ef416.jpg"
  },
  {
    "revision": "0e131bbd227c7215975701e8300e024c",
    "url": "/static/media/bearings2.0e131bbd.png"
  },
  {
    "revision": "6e29682e40c7409962855b9eb9790a36",
    "url": "/static/media/bearings3.6e29682e.jpeg"
  },
  {
    "revision": "ac1c2236502a0f4d4ee2c5d61166832b",
    "url": "/static/media/bearings5.ac1c2236.jpg"
  },
  {
    "revision": "07964a969882c73a920b8dc924ab4498",
    "url": "/static/media/zwzhome1.07964a96.jpg"
  },
  {
    "revision": "85bf090279b6a63d2bcf55051fe62a85",
    "url": "/static/media/zwzhome2.85bf0902.jpg"
  },
  {
    "revision": "1a2dbaa2fff76e567298a20f6aa4d1cf",
    "url": "/static/media/zwzhome3.1a2dbaa2.jpg"
  },
  {
    "revision": "3c9adc386e4180bea65010575abcc4e6",
    "url": "/static/media/zwzproduct12.3c9adc38.jpg"
  },
  {
    "revision": "770eaec2f727a9d44ef096bb8fc3b0ad",
    "url": "/static/media/zwzproduct13.770eaec2.jpg"
  },
  {
    "revision": "2745a24102e388bdee9e104d32556626",
    "url": "/static/media/banner16.2745a241.jpg"
  },
  {
    "revision": "02c7478d9d0253cea5b05b783b9d78d2",
    "url": "/static/media/banner19.02c7478d.jpg"
  },
  {
    "revision": "4b2e58906abcc058d0cce8b06e81c32b",
    "url": "/static/media/banner_slider1.4b2e5890.jpg"
  },
  {
    "revision": "328275d35b774d4325f32be2098a5fd3",
    "url": "/static/media/banner_slider2.328275d3.jpg"
  },
  {
    "revision": "2cbf9ff963c8a72bc95b1ab4edd62f34",
    "url": "/static/media/banner_slider3.2cbf9ff9.jpg"
  },
  {
    "revision": "071c32a84e5d5f20e66390c404f1bc07",
    "url": "/static/media/banner_slider4.071c32a8.jpg"
  },
  {
    "revision": "451fd31339423a747dcec9c18461009e",
    "url": "/static/media/banner_slider5.451fd313.jpg"
  },
  {
    "revision": "e53526a9752e07a3e25ed02d8f207918",
    "url": "/static/media/ca-srb-bearing.e53526a9.jpg"
  },
  {
    "revision": "e53526a9752e07a3e25ed02d8f207918",
    "url": "/static/media/ca-srb-bearing_2.e53526a9.jpg"
  },
  {
    "revision": "9ea844798799996874a7423dab62c5bb",
    "url": "/static/media/cylindrical-roller-bearing.9ea84479.jpg"
  },
  {
    "revision": "9ea844798799996874a7423dab62c5bb",
    "url": "/static/media/cylindrical-roller-bearing_1.9ea84479.jpg"
  },
  {
    "revision": "15edd9265219414f68ea3b2eb0d5c282",
    "url": "/static/media/images-cl_logo1.15edd926.png"
  },
  {
    "revision": "77a8c8c537b4600e7e2eb716bea58681",
    "url": "/static/media/images-cl_logo3.77a8c8c5.png"
  },
  {
    "revision": "e30f5768b1e070da1b72a4ce02bee9c6",
    "url": "/static/media/images-cl_logo5.e30f5768.png"
  },
  {
    "revision": "66f52b9b983298482bb4be22dcd64901",
    "url": "/static/media/images-el_img1.66f52b9b.jpg"
  },
  {
    "revision": "66f52b9b983298482bb4be22dcd64901",
    "url": "/static/media/new1.66f52b9b.jpg"
  },
  {
    "revision": "e53526a9752e07a3e25ed02d8f207918",
    "url": "/static/media/new2.e53526a9.jpg"
  },
  {
    "revision": "9ea844798799996874a7423dab62c5bb",
    "url": "/static/media/new3.9ea84479.jpg"
  },
  {
    "revision": "819881b32077a6cda26b37172e4a7cb3",
    "url": "/static/media/new4.819881b3.jpg"
  },
  {
    "revision": "a1b779bbd1063bd2d58edeef29b44f25",
    "url": "/static/media/new5.a1b779bb.png"
  },
  {
    "revision": "e1ecfe97356c8a248684adc600eab233",
    "url": "/static/media/new6.e1ecfe97.png"
  },
  {
    "revision": "819881b32077a6cda26b37172e4a7cb3",
    "url": "/static/media/self-aligning-bearing.819881b3.jpg"
  },
  {
    "revision": "f535407e293322263e52af7490a426fc",
    "url": "/static/media/spares1.f535407e.jpeg"
  },
  {
    "revision": "6529acbc036235ba105fb02f2d7d8bfb",
    "url": "/static/media/spares2.6529acbc.jpg"
  },
  {
    "revision": "795e0db29238e16c34831fc8d4ab76fd",
    "url": "/static/media/spares3.795e0db2.jpg"
  },
  {
    "revision": "347d435452b96c3fc98bb19894422bed",
    "url": "/static/media/tbanner_slider1.347d4354.jpg"
  },
  {
    "revision": "a1b779bbd1063bd2d58edeef29b44f25",
    "url": "/static/media/thrust-bearing.a1b779bb.png"
  },
  {
    "revision": "e1ecfe97356c8a248684adc600eab233",
    "url": "/static/media/zz-ball-bearing.e1ecfe97.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "912ec66d7572ff821749319396470bde",
    "url": "/static/media/fontawesome-webfont.912ec66d.svg"
  },
  {
    "revision": "a76b5928d2898a93ab2952f6a39e5954",
    "url": "/static/js/2.a7a7185d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8306249e3e5ef2c6fa5b0e74f634cf8b",
    "url": "/index.html"
  }
];